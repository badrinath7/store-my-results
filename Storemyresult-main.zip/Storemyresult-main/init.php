<?php
	//$servername = "localhost";
	//$username = "";
	//$USN = "";
	//$password = "";
	//$conn = mysqli_connect($servername, $username, $password);
	$conn = mysqli_connect("localhost","root","","storemyresult");
	


?>